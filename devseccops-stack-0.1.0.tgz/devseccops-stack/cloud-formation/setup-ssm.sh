#!/usr/bin/env bash
# DevSecOps Platform — SSM Parameter Store management for all services
# Manages environment variables for all 4 services (devseccops-be, devseccops-be-go, devseccops-fe-v2, repo-analyzer)
# Compatible with bash 3.2+ (macOS, Linux, etc.)
#
# Usage:
#   bash cloud-formation/setup-ssm.sh upload   --environment <env> --aws-access-key <key> --aws-secret-key <secret> --github-token <token> --gmail-user <email> --gmail-pass <pass> --backend <url> --engine-repo-owner <owner> --engine-repo-name <name> --frontend <url> --domain <domain> --docker-hub-password <pass> --docker-hub-username <user> --keyid <id> [--region <region>] [--dry-run]
#   bash cloud-formation/setup-ssm.sh download --environment <env> [--output-dir <dir>] [--region <region>]
#   bash cloud-formation/setup-ssm.sh delete   --environment <env> [--region <region>] [--dry-run] [--confirm]

# bash cloud-formation/setup-ssm.sh upload \
#     --environment prod \
#     --aws-access-key <key> \
#     --aws-secret-key <secret> \
#     --gmail-user <email> \
#     --gmail-pass <pass> \
#     --domain <domain> \
#     --frontend <frontend> \
#     --backend <backend> \
#     --engine-repo-owner <owner> \
#     --engine-repo-name <repo-name> \
#     --github-token <token> \
#     --docker-hub-password <pass> \
#     --docker-hub-username <user> \
#     --keyid <id> \
#     --region ap-south-1
#     --dry-run

set -eo pipefail

# ── defaults ──────────────────────────────────────────────────────────────────
COMMAND=""
ENVIRONMENT="prod"
REGION="ap-south-1"
AWS_ACCESS_KEY=""
AWS_SECRET_KEY=""
GITHUB_TOKEN=""
GMAIL_USER=""
GMAIL_PASS=""
BACKEND=""
ENGINE_REPO_OWNER=""
ENGINE_REPO_NAME=""
FRONTEND=""
DOMAIN=""
DOCKER_HUB_PASSWORD=""
DOCKER_HUB_USERNAME=""
KEYID=""
OUTPUT_DIR=""
DRY_RUN=false
CONFIRM=false

# Service definitions (bash 3.2 compatible - no associative arrays)
SERVICES="devseccops-be devseccops-be-go devseccops-fe-v2 repo-analyzer"

get_ssm_path() {
  local service="$1"
  case "$service" in
    devseccops-be)    echo "/$ENVIRONMENT/devseccops-be/config" ;;
    devseccops-be-go) echo "/$ENVIRONMENT/devseccops-be-go/config" ;;
    devseccops-fe-v2) echo "/$ENVIRONMENT/devseccops-fe-v2" ;;
    repo-analyzer)    echo "/$ENVIRONMENT/repo-analyzer" ;;
    *) echo "" ;;
  esac
}

# ── colors ────────────────────────────────────────────────────────────────────
if [[ -t 1 ]]; then
  # Colors enabled (terminal supports it)
  BOLD='\033[1m'
  GREEN='\033[0;32m'
  BLUE='\033[0;34m'
  CYAN='\033[0;36m'
  YELLOW='\033[0;33m'
  RED='\033[0;31m'
  MAGENTA='\033[0;35m'
  RESET='\033[0m'
else
  # No colors (pipe/redirect)
  BOLD="" GREEN="" BLUE="" CYAN="" YELLOW="" RED="" MAGENTA="" RESET=""
fi

# ── helper functions ───────────────────────────────────────────────────────────
log()     { echo -e "${BLUE}[INFO]${RESET}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${RESET}    $*" >&2; }
error()   { echo -e "${RED}[ERROR]${RESET}   $*" >&2; exit 1; }
dry_log() { echo -e "${MAGENTA}[DRY-RUN]${RESET} $*"; }
success() { echo -e "${GREEN}[SUCCESS]${RESET} $*"; }

# Print a formatted table (bash 3.2 compatible)
print_table() {
  local max_key=25 max_val=60
  local total_width=$((max_key + max_val + 7))
  local border=$(printf '%*s' "$total_width" | tr ' ' '-')

  echo -e "${CYAN}$border${RESET}"
  printf "${BOLD}| %-${max_key}s | %-${max_val}s |${RESET}\n" "Service / Parameter" "Value"
  echo -e "${CYAN}$border${RESET}"

  # Read from stdin in format "key|value"
  while IFS='|' read -r key value; do
    printf "| ${GREEN}%-${max_key}s${RESET} | %-${max_val}s |\n" "$key" "$value"
  done

  echo -e "${CYAN}$border${RESET}"
}

usage() {
  cat <<EOF
Usage: $(basename "$0") <command> [options]

Commands:
  upload    Upload environment variables for all 4 services to SSM
  download  Download all parameters from SSM to local env files
  delete    Delete all parameters for all services from SSM

Upload Options:
  --environment                 Environment name (e.g. dev, prod)               [required]
  --aws-access-key              AWS Access Key ID for services                  [required]
  --aws-secret-key              AWS Secret Access Key for services              [required]
  --github-token                GitHub Personal Access Token                    [required]
  --gmail-user                  Gmail username for notifications                [required]
  --gmail-pass                  Gmail app password                              [required]
  --backend                    Frontend API base URL                           [required]
  --engine-repo-owner           Engine repository owner                         [required]
  --engine-repo-name            Engine repository name                          [required]
  --frontend                    Frontend URL                                    [required]
  --domain                      Domain name                                     [required]
  --docker-hub-password         Docker Hub password                             [required]
  --docker-hub-username         Docker Hub username                             [required]
  --keyid                       License Key ID                                  [required]
  --region                      AWS region (default: ap-south-1)
  --dry-run                     Preview what would be uploaded without changes

Download Options:
  --environment         Environment name (e.g. dev, prod)               [required]
  --output-dir          Directory to save env files (default: ./envs)
  --region              AWS region (default: ap-south-1)

Delete Options:
  --environment         Environment name (e.g. dev, prod)               [required]
  --region              AWS region (default: ap-south-1)
  --dry-run             Preview what would be deleted without changes
  --confirm             Required flag to confirm deletion

Examples:
  # Upload (dry-run preview)
  bash setup-ssm.sh upload --environment prod --aws-access-key AKIAXXXX --aws-secret-key xxxx --github-token ghp_xxx --gmail-user user@gmail.com --gmail-pass apppass --backend https://api.example.com --engine-repo-owner myorg --engine-repo-name engine --frontend https://example.com --domain example.com --docker-hub-password dockerpass --docker-hub-username dockeruser --keyid key123 --dry-run

  # Upload (real)
  bash setup-ssm.sh upload --environment prod --aws-access-key AKIAXXXX --aws-secret-key xxxx --github-token ghp_xxx --gmail-user user@gmail.com --gmail-pass apppass --backend https://api.example.com --engine-repo-owner myorg --engine-repo-name engine --frontend https://example.com --domain example.com --docker-hub-password dockerpass --docker-hub-username dockeruser --keyid key123

  # Download all env files
  bash setup-ssm.sh download --environment prod --output-dir ./my-envs

  # Delete (dry-run preview)
  bash setup-ssm.sh delete --environment prod --dry-run

  # Delete (real - requires --confirm)
  bash setup-ssm.sh delete --environment prod --confirm
EOF
}

# ── parse args ─────────────────────────────────────────────────────────────────
if [[ $# -gt 0 && "$1" != -* ]]; then
  COMMAND="$1"
  shift
fi

while [[ $# -gt 0 ]]; do
  case "$1" in
    --environment)                 ENVIRONMENT="$2"; shift 2 ;;
    --aws-access-key)              AWS_ACCESS_KEY="$2"; shift 2 ;;
    --aws-secret-key)              AWS_SECRET_KEY="$2"; shift 2 ;;
    --github-token)                GITHUB_TOKEN="$2"; shift 2 ;;
    --gmail-user)                  GMAIL_USER="$2"; shift 2 ;;
    --gmail-pass)                  GMAIL_PASS="$2"; shift 2 ;;
    --backend)                     BACKEND="$2"; shift 2 ;;
    --engine-repo-owner)           ENGINE_REPO_OWNER="$2"; shift 2 ;;
    --engine-repo-name)            ENGINE_REPO_NAME="$2"; shift 2 ;;
    --frontend)                    FRONTEND="$2"; shift 2 ;;
    --domain)                      DOMAIN="$2"; shift 2 ;;
    --docker-hub-password)         DOCKER_HUB_PASSWORD="$2"; shift 2 ;;
    --docker-hub-username)         DOCKER_HUB_USERNAME="$2"; shift 2 ;;
    --keyid)                       KEYID="$2"; shift 2 ;;
    --region)                      REGION="$2"; shift 2 ;;
    --output-dir)                  OUTPUT_DIR="$2"; shift 2 ;;
    --dry-run)                     DRY_RUN=true; shift ;;
    --confirm)                     CONFIRM=true; shift ;;
    -h|--help)                     usage; exit 0 ;;
    *) error "Unknown option: $1" ;;
  esac
done

[[ -z "$COMMAND" ]]     && { usage; error "Command is required (upload | download | delete)"; }
[[ -z "$ENVIRONMENT" ]] && error "--environment is required"

# ── upload helper ──────────────────────────────────────────────────────────────
upload_param() {
  local path="$1"
  local value="$2"
  local mask="${3:-false}"

  if [[ -z "$value" ]]; then
    warn "Skipping empty value (AWS SSM requires non-empty values): $path"
    return 1
  fi

  if $DRY_RUN; then
    if [[ "$mask" == "true" ]]; then
      dry_log "Would upload: $path = ${value:0:4}****"
    else
      dry_log "Would upload: $path = $value"
    fi
  else
    aws ssm put-parameter \
      --region "$REGION" \
      --name "$path" \
      --value "$value" \
      --type SecureString \
      --overwrite \
      --output text > /dev/null
    log "Uploaded: $path"
  fi
  return 0
}

# ══════════════════════════════════════════════════════════════════════════════
# COMMAND: UPLOAD
# ══════════════════════════════════════════════════════════════════════════════
cmd_upload() {
  if [[ -z "$AWS_ACCESS_KEY" || -z "$AWS_SECRET_KEY" || -z "$GITHUB_TOKEN" || -z "$GMAIL_USER" || -z "$GMAIL_PASS" || -z "$BACKEND" || -z "$ENGINE_REPO_OWNER" || -z "$ENGINE_REPO_NAME" || -z "$FRONTEND" || -z "$DOMAIN" || -z "$DOCKER_HUB_PASSWORD" || -z "$DOCKER_HUB_USERNAME" || -z "$KEYID" ]]; then
    error "Upload requires: --aws-access-key, --aws-secret-key, --github-token, --gmail-user, --gmail-pass, --backend, --engine-repo-owner, --engine-repo-name, --frontend, --domain, --docker-hub-password, --docker-hub-username, --keyid"
  fi

  # Auto-generate INTERNAL_SERVICE_KEY for all services
  INTERNAL_SERVICE_KEY=$(openssl rand -hex 32)
  log "Generated INTERNAL_SERVICE_KEY for secure service-to-service communication"

  # Get AWS Account ID dynamically
  AWS_ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text 2>/dev/null)
  if [[ -z "$AWS_ACCOUNT_ID" ]]; then
    error "Failed to retrieve AWS Account ID. Ensure AWS CLI is configured correctly."
  fi
  log "Using AWS Account ID: $AWS_ACCOUNT_ID"

  BEDROCK_MODEL_1="global.anthropic.claude-haiku-4-5-20251001-v1:0"
  BEDROCK_MODEL_2="anthropic.claude-3-haiku-20240307-v1:0"

  $DRY_RUN && warn "DRY-RUN mode — no changes will be made to AWS"

  # Initialize counters for each service
  local count_fe=0 count_be=0 count_be_go=0 count_ra=0

# ────────────────────────────────────────────────────────────────────────────
  # SERVICE 1: devseccops-fe-v2
  # ────────────────────────────────────────────────────────────────────────────
  echo ""
  echo -e "${CYAN}────────────────────────────────────────────────────────────${RESET}"
  echo -e "${BOLD}Uploading environment variables for devseccops-fe-v2 ...${RESET}"
  echo -e "${CYAN}────────────────────────────────────────────────────────────${RESET}"

  SSM_BASE_FE="/$ENVIRONMENT/devseccops-fe-v2"

  upload_param "$SSM_BASE_FE/NEXT_PUBLIC_API_BASE_URL" "$BACKEND" && ((count_fe++))
  upload_param "$SSM_BASE_FE/DEPLOYMENT_MODE" "k8s" && ((count_fe++))


  # ────────────────────────────────────────────────────────────────────────────
  # SERVICE 2: devseccops-be
  # ────────────────────────────────────────────────────────────────────────────
  echo ""
  echo -e "${CYAN}────────────────────────────────────────────────────────────${RESET}"
  echo -e "${BOLD}Uploading environment variables for devseccops-be ...${RESET}"
  echo -e "${CYAN}────────────────────────────────────────────────────────────${RESET}"

  SSM_BASE_BE="/$ENVIRONMENT/devseccops-be/config"

  upload_param "$SSM_BASE_BE/AWS_ACCESS_KEY_ID" "$AWS_ACCESS_KEY" true && ((count_be++))
  upload_param "$SSM_BASE_BE/AWS_SECRET_ACCESS_KEY" "$AWS_SECRET_KEY" true && ((count_be++))
  upload_param "$SSM_BASE_BE/GITHUB_TOKEN" "$GITHUB_TOKEN" true && ((count_be++))
  upload_param "$SSM_BASE_BE/GMAIL_USER" "$GMAIL_USER" && ((count_be++))
  upload_param "$SSM_BASE_BE/GMAIL_PASS" "$GMAIL_PASS" true && ((count_be++))
  upload_param "$SSM_BASE_BE/REGION" "$REGION" && ((count_be++))
  upload_param "$SSM_BASE_BE/NODE_ENV" "production" && ((count_be++))
  upload_param "$SSM_BASE_BE/LOG_LEVEL" "info" && ((count_be++))
  upload_param "$SSM_BASE_BE/BEDROCK_AWS_ACCESS_KEY_ID" "$AWS_ACCESS_KEY" true && ((count_be++))
  upload_param "$SSM_BASE_BE/BEDROCK_AWS_SECRET_ACCESS_KEY" "$AWS_SECRET_KEY" true && ((count_be++))
  upload_param "$SSM_BASE_BE/BEDROCK_AWS_REGION" "$REGION" && ((count_be++))
  upload_param "$SSM_BASE_BE/BEDROCK_MODEL" "$BEDROCK_MODEL_1" && ((count_be++))
  upload_param "$SSM_BASE_BE/BEDROCK_MODEL_CICD" "$BEDROCK_MODEL_1" && ((count_be++))
  upload_param "$SSM_BASE_BE/BEDROCK_MODEL_ECS" "$BEDROCK_MODEL_2" && ((count_be++))
  upload_param "$SSM_BASE_BE/BEDROCK_MODEL_EKS" "$BEDROCK_MODEL_2" && ((count_be++))
  upload_param "$SSM_BASE_BE/ENABLE_CACHE" "true" && ((count_be++))


  # Engine configuration
  upload_param "$SSM_BASE_BE/ENGINE_REPO_OWNER" "$ENGINE_REPO_OWNER" && ((count_be++))
  upload_param "$SSM_BASE_BE/ENGINE_REPO_NAME" "$ENGINE_REPO_NAME" && ((count_be++))
  upload_param "$SSM_BASE_BE/SECURITY_SCAN_NAMESPACE" "devseccops" && ((count_be++))
  upload_param "$SSM_BASE_BE/ENGINE_NAMESPACE" "devseccops" && ((count_be++))

  # JWT configuration
  upload_param "$SSM_BASE_BE/JWT_SECRET" "asdfghjkl" && ((count_be++))
  upload_param "$SSM_BASE_BE/JWT_REFRESH_SECRET" "qwertyuiop_refresh_secret_key" && ((count_be++))
  upload_param "$SSM_BASE_BE/JWT_EXPIRE" "5h" && ((count_be++))
  upload_param "$SSM_BASE_BE/JWT_REFRESH_EXPIRE" "7d" && ((count_be++))
  upload_param "$SSM_BASE_BE/JWT_COOKIE_EXPIRE" "1" && ((count_be++))
  upload_param "$SSM_BASE_BE/JWT_REFRESH_COOKIE_EXPIRE" "7" && ((count_be++))

  # MongoDB configuration (no auth for dev environment)
  upload_param "$SSM_BASE_BE/MONGO_URI" "mongodb://mongo-0.mongo.devseccops.svc.cluster.local:27017/test" && ((count_be++))
  upload_param "$SSM_BASE_BE/MONGO_DATABASE" "test" && ((count_be++))

  # Redis configuration
  upload_param "$SSM_BASE_BE/REDIS_HOST" "be-redis-service.devseccops.svc.cluster.local" && ((count_be++))
  upload_param "$SSM_BASE_BE/REDIS_PORT" "6379" && ((count_be++))

  # License configuration
  upload_param "$SSM_BASE_BE/VERIFY_LICENSE_ON_STARTUP" "true" && ((count_be++))
  upload_param "$SSM_BASE_BE/LICENSE_JWT" "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJjbGllbnRJZCI6ImNsaWVudC0zMjhhYmZkNC1lZDAxLTQyMzAtOWNlNC04YTJiNmY2OWQzNWIiLCJjbGllbnROYW1lIjoiRGV2c2VjY29wcy5haSIsImZlYXR1cmVzIjp7ImNpY2QiOnRydWUsInNlY3VyaXR5U2NhbiI6dHJ1ZSwiY29zdE9wdGltaXphdGlvbiI6dHJ1ZSwiY2x1c3Rlck1vbml0b3JpbmciOnRydWUsImluZnJhQXNDb2RlIjp0cnVlLCJtdWx0aUNsb3VkIjp7ImF3cyI6dHJ1ZSwiYXp1cmUiOnRydWUsImdjcCI6dHJ1ZX19LCJsaW1pdHMiOnsibWF4VXNlcnMiOjUsIm1heFByb2plY3RzIjozLCJtYXhDbHVzdGVycyI6MX0sInBsYW4iOiJwcm8iLCJpc3N1ZWRBdCI6MTc3Njc2Njg0NTM0MSwiZXhwaXJlc0F0IjoxODA4MzAyODQ1MzQxLCJpc3MiOiJkZXZzZWNjb3BzLWxpY2Vuc2Utc2VydmVyIiwiaWF0IjoxNzc2NzY2ODQ1LCJleHAiOjE4MDgzMDI4NDV9.j_DFMMlGojOCis1my8-Xikx_vAEBUKnh_j0GKWpnWpPy8kEAuknWl9Rgz_6WIlYLsz_gQDnHxjJqDybtQio56GF_7j76hdBxS4A1ZMIEQ9h5k0hc1jLizFGDY5GDxEwwvdsTwjOjdik0JivJjFjADi6haOvoGEgTJBsrmmNfp72yJMObdS9wWSMjwSU91nsZYRrqw58Oba9gV6COZadu8mm2o3asK6BnFkMJGqnRHN8fzABe0j9P91rH1sJjeBGaCq3UNNMqSp73nzQXLTxn0pY6hwhp5D569tGyA4xEQG-8QGsTh_mfk0aPGKJAGv43-TsWq_KQKYx4wSrlnP0IifGrAOgurhI0BtPAIhTCDsqRrAEG9_RdPRhBh6voD226miUW0ywo5Wgtowc_WuNmbWPOThPzCCrcFH7wgUF872su_KJq6hOgbIeJN91erLsKuhKhhRnZWESTP0VL8s_GGok00HeNV-H8yWKm5KRg57LjaDob-DfLbjHJMucDVMwlKu_XN-hQo7EAv8nKa9kV4F0X9v9l88PMeCeOcW9M3o0vXyMWkX0OHuS3e4eW3mYZeJl1KJTPcf1wSKUc1013vplPjV6xvhUjxx46VHTZgEumZAsb1Sh4lTwdXxUeotCTmHbBakPWISKrtBvmGWntg-ZOUdPC_H9kBo2pjvwc2Cw" true && ((count_be++))
  upload_param "$SSM_BASE_BE/LICENSE_PUBLIC_KEY_PATH" "./config/license/public-key.pem" && ((count_be++))
  upload_param "$SSM_BASE_BE/LICENSE_SERVER_URL" "https://devseccops-license.devseccops.ai" && ((count_be++))
  upload_param "$SSM_BASE_BE/KEYID" "$KEYID" && ((count_be++))
  upload_param "$SSM_BASE_BE/PUBLIC_KEY_CACHE_TTL" "3600" && ((count_be++))

  # Service URLs
  upload_param "$SSM_BASE_BE/FRONTEND" "$FRONTEND" && ((count_be++))
  upload_param "$SSM_BASE_BE/DOMAIN" "$DOMAIN" && ((count_be++))
  upload_param "$SSM_BASE_BE/BACKENDGO" "http://devseccops-devseccops-be-go.devseccops.svc.cluster.local" && ((count_be++))
  upload_param "$SSM_BASE_BE/BACKEND_REPO_ANALYSER" "http://devseccops-repo-analyzer-api.devseccops.svc.cluster.local" && ((count_be++))
  upload_param "$SSM_BASE_BE/REPO_ANALYZER_HOST" "devseccops-repo-analyzer-api.devseccops.svc.cluster.local:50051" && ((count_be++))

  # Security & Rate Limiting
  upload_param "$SSM_BASE_BE/SECURE_COOKIE" "true" && ((count_be++))
  upload_param "$SSM_BASE_BE/SAME_SITE" "Strict" && ((count_be++))
  upload_param "$SSM_BASE_BE/RATE_LIMIT_MAX" "10000" && ((count_be++))
  upload_param "$SSM_BASE_BE/RATE_LIMIT_WINDOW" "900000" && ((count_be++))


  upload_param "$SSM_BASE_BE/INTERNAL_SERVICE_KEY" "$INTERNAL_SERVICE_KEY" true && ((count_be++))

  # ────────────────────────────────────────────────────────────────────────────
  # SERVICE 3: devseccops-be-go
  # ────────────────────────────────────────────────────────────────────────────
  echo ""
  echo -e "${CYAN}────────────────────────────────────────────────────────────${RESET}"
  echo -e "${BOLD}Uploading environment variables for devseccops-be-go ...${RESET}"
  echo -e "${CYAN}────────────────────────────────────────────────────────────${RESET}"

  SSM_BASE_BE_GO="/$ENVIRONMENT/devseccops-be-go/config"

  upload_param "$SSM_BASE_BE_GO/addr" ":3003" && ((count_be_go++))
  upload_param "$SSM_BASE_BE_GO/env" "production" && ((count_be_go++))
  upload_param "$SSM_BASE_BE_GO/HELM_DRIVER" "secret" && ((count_be_go++))
  upload_param "$SSM_BASE_BE_GO/POSTGRES_USERNAME" "sonar" && ((count_be_go++))
  upload_param "$SSM_BASE_BE_GO/POSTGRES_PASSWORD" "sonarqube"  true && ((count_be_go++))
  upload_param "$SSM_BASE_BE_GO/POSTGRES_DATABASE" "sonarqube"  true && ((count_be_go++))
  upload_param "$SSM_BASE_BE_GO/POSTGRES_STORAGE_CLASS" "gp3" && ((count_be_go++))
  upload_param "$SSM_BASE_BE_GO/POSTGRES_STORAGE_SIZE" "20Gi" && ((count_be_go++))
  upload_param "$SSM_BASE_BE_GO/SONARQUBE_CHART_VERSION" "" && ((count_be_go++))
  upload_param "$SSM_BASE_BE_GO/JENKINS_CHART_VERSION" "5.9.9" && ((count_be_go++))
  upload_param "$SSM_BASE_BE_GO/INTERNAL_SERVICE_KEY" "$INTERNAL_SERVICE_KEY" true && ((count_be_go++))

  # ────────────────────────────────────────────────────────────────────────────
  # SERVICE 4: repo-analyzer
  # ────────────────────────────────────────────────────────────────────────────
  echo ""
  echo -e "${CYAN}────────────────────────────────────────────────────────────${RESET}"
  echo -e "${BOLD}Uploading environment variables for repo-analyzer ...${RESET}"
  echo -e "${CYAN}────────────────────────────────────────────────────────────${RESET}"

  SSM_BASE_RA="/$ENVIRONMENT/repo-analyzer"

  upload_param "$SSM_BASE_RA/AWS_ACCESS_KEY_ID" "$AWS_ACCESS_KEY" true && ((count_ra++))
  upload_param "$SSM_BASE_RA/AWS_SECRET_ACCESS_KEY" "$AWS_SECRET_KEY" true && ((count_ra++))
  upload_param "$SSM_BASE_RA/BEDROCK_AWS_ACCESS_KEY_ID" "$AWS_ACCESS_KEY" true && ((count_ra++))
  upload_param "$SSM_BASE_RA/BEDROCK_AWS_SECRET_ACCESS_KEY" "$AWS_SECRET_KEY" true && ((count_ra++))
  upload_param "$SSM_BASE_RA/AWS_REGION" "$REGION" && ((count_ra++))
  upload_param "$SSM_BASE_RA/BEDROCK_AWS_REGION" "$REGION" && ((count_ra++))
  upload_param "$SSM_BASE_RA/BEDROCK_MODEL" "$BEDROCK_MODEL_1" && ((count_ra++))
  upload_param "$SSM_BASE_RA/NODE_ENV" "development" && ((count_ra++))
  upload_param "$SSM_BASE_RA/LOG_LEVEL" "info" && ((count_ra++))
  upload_param "$SSM_BASE_RA/PORT" "3005" && ((count_ra++))
  upload_param "$SSM_BASE_RA/GRPC_PORT" "50051" && ((count_ra++))
  upload_param "$SSM_BASE_RA/BUILDER_TYPE" "buildkit" && ((count_ra++))
  upload_param "$SSM_BASE_RA/KANIKO_IMAGE" "gcr.io/kaniko-project/executor:v1.24.0" && ((count_ra++))
  upload_param "$SSM_BASE_RA/BUILDKIT_IMAGE" "moby/buildkit:v0.21.1-rootless" && ((count_ra++))
  upload_param "$SSM_BASE_RA/JOB_CONCURRENCY" "3" && ((count_ra++))
  upload_param "$SSM_BASE_RA/JOB_TIMEOUT" "4000000" && ((count_ra++))
  upload_param "$SSM_BASE_RA/BUILD_TIMEOUT" "2400000" && ((count_ra++))
  upload_param "$SSM_BASE_RA/CLONE_TIMEOUT_MS" "600000" && ((count_ra++))
  upload_param "$SSM_BASE_RA/TEST_POD_TIMEOUT" "120000" && ((count_ra++))
  upload_param "$SSM_BASE_RA/MAX_BUILD_ATTEMPTS" "15" && ((count_ra++))
  upload_param "$SSM_BASE_RA/KANIKO_NO_PUSH" "false" && ((count_ra++))
  upload_param "$SSM_BASE_RA/TEMP_DIR" "/tmp/repo-analyzer" && ((count_ra++))
  upload_param "$SSM_BASE_RA/SERVICE_ACCOUNT_NAME" "prod-repo-analyzer-sa" && ((count_ra++))
  upload_param "$SSM_BASE_RA/NAMESPACE" "devseccops" && ((count_ra++))
  upload_param "$SSM_BASE_RA/REDIS_HOST" "redis-service.devseccops.svc.cluster.local" && ((count_ra++))
  upload_param "$SSM_BASE_RA/REDIS_PORT" "6379" && ((count_ra++))
  upload_param "$SSM_BASE_RA/INTERNAL_SERVICE_KEY" "$INTERNAL_SERVICE_KEY" true && ((count_ra++))
  upload_param "$SSM_BASE_RA/DOCKER_HUB_PASSWORD" "$DOCKER_HUB_PASSWORD"  true && ((count_ra++))
  upload_param "$SSM_BASE_RA/DOCKER_HUB_USERNAME" "$DOCKER_HUB_USERNAME"  true && ((count_ra++))
  upload_param "$SSM_BASE_RA/BUILDKIT_TEST_REGISTRY" "$AWS_ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com/repo-analyzer-test"  true && ((count_ra++))
  upload_param "$SSM_BASE_RA/BUILDKIT_CACHE_REPO" "$AWS_ACCOUNT_ID.dkr.ecr.$REGION.amazonaws.com/buildkit-cache"  true && ((count_ra++))

  # upload_param "$SSM_BASE_RA/KANIKO_CACHE_REPO" "PLACEHOLDER_UPDATE_REQUIRED"

  # ────────────────────────────────────────────────────────────────────────────
  echo ""
  echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
  if $DRY_RUN; then
    echo -e "${BOLD}${MAGENTA}DRY-RUN COMPLETE${RESET} ${YELLOW}— No parameters were uploaded${RESET}"
    echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
    echo ""
    log "Re-run without --dry-run to apply changes"
  else
    echo -e "${BOLD}${GREEN}✓ UPLOAD COMPLETE${RESET}"
    echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
    echo ""

    {
      echo "devseccops-be|/$ENVIRONMENT/devseccops-be/config/* ($count_be parameters)"
      echo "devseccops-be-go|/$ENVIRONMENT/devseccops-be-go/config/* ($count_be_go parameters)"
      echo "devseccops-fe-v2|/$ENVIRONMENT/devseccops-fe-v2/* ($count_fe parameters)"
      echo "repo-analyzer|/$ENVIRONMENT/repo-analyzer/* ($count_ra parameters)"
    } | print_table

    echo ""
    # echo -e "${BOLD}Next steps:${RESET}"
    # echo -e "  ${CYAN}1.${RESET} Update PLACEHOLDER values in AWS SSM Parameter Store"
    # echo -e "  ${CYAN}2.${RESET} View parameters: ${BOLD}aws ssm get-parameters-by-path --path /$ENVIRONMENT/devseccops-be/config --with-decryption${RESET}"
    # echo -e "  ${CYAN}3.${RESET} Install Helm chart: ${BOLD}helm install devseccops devseccops-stack/ --namespace devseccops${RESET}"
  fi
}

# ══════════════════════════════════════════════════════════════════════════════
# COMMAND: DOWNLOAD
# ══════════════════════════════════════════════════════════════════════════════
cmd_download() {
  [[ -z "$OUTPUT_DIR" ]] && OUTPUT_DIR="./envs"
  mkdir -p "$OUTPUT_DIR"

  log "Downloading parameters from SSM to $OUTPUT_DIR"

  for service in $SERVICES; do
    local ssm_path=$(get_ssm_path "$service")
    local output_file="$OUTPUT_DIR/$service.env"

    log ""
    log "Downloading $service → $output_file"

    local tmp_file next_token="" page
    tmp_file=$(mktemp)

    while true; do
      if [[ -n "$next_token" ]]; then
        page=$(aws ssm get-parameters-by-path --path "$ssm_path" --with-decryption --region "$REGION" --output json --next-token "$next_token" 2>/dev/null || echo '{}')
      else
        page=$(aws ssm get-parameters-by-path --path "$ssm_path" --with-decryption --region "$REGION" --output json 2>/dev/null || echo '{}')
      fi

      # Extract key=value lines
      awk -F'"' -v prefix="$ssm_path" '
        /\"Name\"/  && $4 ~ /^\// { name = substr($4, length(prefix)+2) }
        /\"Value\"/ && name != "" { print name "=" $4; name = "" }
      ' <<< "$page" >> "$tmp_file"

      next_token=$(awk -F'"' '/\"NextToken\"/{print $4}' <<< "$page")
      [[ -z "$next_token" ]] && break
    done

    if [[ -s "$tmp_file" ]]; then
      mv "$tmp_file" "$output_file"
      log "✓ Downloaded $(wc -l < "$output_file" | tr -d ' ') parameters"
    else
      rm -f "$tmp_file"
      warn "No parameters found at $ssm_path"
    fi
  done

  echo ""
  echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
  echo -e "${BOLD}${GREEN}✓ DOWNLOAD COMPLETE${RESET}"
  echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
  echo ""

  {
    for service in $SERVICES; do
      local file="$OUTPUT_DIR/$service.env"
      if [[ -f "$file" ]]; then
        local count=$(wc -l < "$file" | tr -d ' ')
        echo "$service|$file ($count parameters)"
      else
        echo "$service|Not found"
      fi
    done
  } | print_table

  echo ""
  success "Files saved to: $OUTPUT_DIR"
}

# ══════════════════════════════════════════════════════════════════════════════
# COMMAND: DELETE
# ══════════════════════════════════════════════════════════════════════════════
cmd_delete() {
  log "Fetching parameters under environment: $ENVIRONMENT"

  local all_params=()
  local count_be=0 count_be_go=0 count_fe=0 count_ra=0

  for service in $SERVICES; do
    local ssm_path=$(get_ssm_path "$service")
    local next_token="" page

    log ""
    log "Scanning $service at $ssm_path ..."

    while true; do
      if [[ -n "$next_token" ]]; then
        page=$(aws ssm get-parameters-by-path --path "$ssm_path" --region "$REGION" --output json --next-token "$next_token" 2>/dev/null || echo '{}')
      else
        page=$(aws ssm get-parameters-by-path --path "$ssm_path" --region "$REGION" --output json 2>/dev/null || echo '{}')
      fi

      while IFS= read -r name; do
        if [[ -n "$name" ]]; then
          all_params+=("$name")
          case "$service" in
            devseccops-be)    ((count_be++)) ;;
            devseccops-be-go) ((count_be_go++)) ;;
            devseccops-fe-v2) ((count_fe++)) ;;
            repo-analyzer)    ((count_ra++)) ;;
          esac
        fi
      done < <(awk -F'"' '/\"Name\"/ && $4 ~ /^\// {print $4}' <<< "$page")

      next_token=$(awk -F'"' '/\"NextToken\"/{print $4}' <<< "$page")
      [[ -z "$next_token" ]] && break
    done
  done

  if [[ ${#all_params[@]} -eq 0 ]]; then
    warn "No parameters found for environment: $ENVIRONMENT"
    exit 0
  fi

  echo ""
  echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
  echo -e "${BOLD}${YELLOW}⚠ PARAMETERS FOUND${RESET}"
  echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
  echo ""

  {
    echo "devseccops-be|/$ENVIRONMENT/devseccops-be/config/* ($count_be parameters)"
    echo "devseccops-be-go|/$ENVIRONMENT/devseccops-be-go/config/* ($count_be_go parameters)"
    echo "devseccops-fe-v2|/$ENVIRONMENT/devseccops-fe-v2/* ($count_fe parameters)"
    echo "repo-analyzer|/$ENVIRONMENT/repo-analyzer/* ($count_ra parameters)"
  } | print_table

  echo ""
  echo -e "${BOLD}Total parameters to delete: ${RED}${#all_params[@]}${RESET}"
  echo ""

  if $DRY_RUN; then
    echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
    echo -e "${BOLD}${MAGENTA}DRY-RUN COMPLETE${RESET} ${YELLOW}— No parameters were deleted${RESET}"
    echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
    echo ""
    log "Re-run with --confirm to actually delete these parameters"
    exit 0
  fi

  if ! $CONFIRM; then
    error "Deletion requires --confirm flag. Re-run with --confirm to proceed."
  fi

  # SSM delete-parameters accepts up to 10 names at a time
  local batch=()
  local deleted=0

  log "Deleting parameters ..."
  for p in "${all_params[@]}"; do
    batch+=("$p")
    if [[ ${#batch[@]} -eq 10 ]]; then
      aws ssm delete-parameters \
        --region "$REGION" \
        --names "${batch[@]}" \
        --output text > /dev/null
      ((deleted += ${#batch[@]}))
      batch=()
    fi
  done

  # Flush remaining
  if [[ ${#batch[@]} -gt 0 ]]; then
    aws ssm delete-parameters \
      --region "$REGION" \
      --names "${batch[@]}" \
      --output text > /dev/null
    ((deleted += ${#batch[@]}))
  fi

  echo ""
  echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
  echo -e "${BOLD}${GREEN}✓ DELETE COMPLETE${RESET}"
  echo -e "${CYAN}════════════════════════════════════════════════════════════${RESET}"
  echo ""

  {
    echo "devseccops-be|/$ENVIRONMENT/devseccops-be/config/* ($count_be deleted)"
    echo "devseccops-be-go|/$ENVIRONMENT/devseccops-be-go/config/* ($count_be_go deleted)"
    echo "devseccops-fe-v2|/$ENVIRONMENT/devseccops-fe-v2/* ($count_fe deleted)"
    echo "repo-analyzer|/$ENVIRONMENT/repo-analyzer/* ($count_ra deleted)"
  } | print_table

  echo ""
  success "Total deleted: $deleted parameter(s) from environment: $ENVIRONMENT"
}

# ── dispatch ───────────────────────────────────────────────────────────────────
case "$COMMAND" in
  upload)   cmd_upload ;;
  download) cmd_download ;;
  delete)   cmd_delete ;;
  *) usage; error "Unknown command: $COMMAND" ;;
esac
