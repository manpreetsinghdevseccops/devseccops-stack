#!/usr/bin/env bash
# DevSecOps Platform — IAM setup script
# Embeds the CloudFormation template — no public S3 or file download needed.
# The client only needs AWS CLI + IAM/CloudFormation permissions.
#
# Usage:
#   bash cloud-formation/setup-iam.sh --cluster <eks-cluster-name> [--prefix prod] [--namespace devseccops] [--region ap-south-1]
#   bash cloud-formation/setup-iam.sh --cluster <eks-cluster-name> --dry-run
#   bash cloud-formation/setup-iam.sh --delete [--stack devseccops-iam] [--region ap-south-1]
#   bash cloud-formation/setup-iam.sh --delete [--stack devseccops-iam] [--region ap-south-1] --dry-run

# bash cloud-formation/setup-iam.sh --delete  --region ap-south-1

# bash cloud-formation/setup-iam.sh \
# --namespace devseccops \
# --prefix prod \
# --cluster <cluster-name> \
# --kms-key <key> \       #optional
# --region ap-south-1


set -euo pipefail

# ── defaults ──────────────────────────────────────────────────────────────────
CLUSTER_NAME=""
PREFIX="prod"
NAMESPACE="devseccops"
REGION="ap-south-1"
STACK_NAME="devseccops-iam"
KMS_KEY_ID=""
DRY_RUN=false
DELETE=false

# ── parse args ─────────────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --cluster)   CLUSTER_NAME="$2"; shift 2 ;;
    --prefix)    PREFIX="$2";       shift 2 ;;
    --namespace) NAMESPACE="$2";    shift 2 ;;
    --region)    REGION="$2";       shift 2 ;;
    --stack)     STACK_NAME="$2";   shift 2 ;;
    --kms-key)   KMS_KEY_ID="$2";   shift 2 ;;
    --dry-run)   DRY_RUN=true;      shift 1 ;;
    --delete)    DELETE=true;       shift 1 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ── handle delete mode ─────────────────────────────────────────────────────────
if [[ "$DELETE" == "true" ]]; then
  echo "Stack name: $STACK_NAME"
  echo "Region:     $REGION"
  echo ""

  # Check if stack exists
  STACK_STATUS=$(aws cloudformation describe-stacks --region "$REGION" --stack-name "$STACK_NAME" --query "Stacks[0].StackStatus" --output text 2>/dev/null || echo "DOES_NOT_EXIST")

  if [[ "$STACK_STATUS" == "DOES_NOT_EXIST" ]]; then
    echo "Stack '$STACK_NAME' does not exist in region '$REGION'."
    exit 0
  fi

  echo "Current stack status: $STACK_STATUS"
  echo ""

  # Fetch and display resources that will be deleted
  echo "Resources that will be deleted:"
  aws cloudformation describe-stack-resources \
    --region "$REGION" \
    --stack-name "$STACK_NAME" \
    --query "StackResources[*].{Type:ResourceType,LogicalID:LogicalResourceId,PhysicalID:PhysicalResourceId}" \
    --output table

  echo ""
  echo "Stack outputs:"
  aws cloudformation describe-stacks \
    --region "$REGION" \
    --stack-name "$STACK_NAME" \
    --query "Stacks[0].Outputs[*].[OutputKey,OutputValue]" \
    --output table 2>/dev/null || echo "No outputs found"

  if [[ "$DRY_RUN" == "true" ]]; then
    echo ""
    echo "DRY-RUN MODE: No resources will be deleted."
    echo "Re-run without --dry-run to actually delete the stack."
    exit 0
  fi

  echo ""
  echo "WARNING: This will delete the CloudFormation stack and all associated resources:"
  echo "  - 4 IAM Roles (devseccops-be, devseccops-be-go, devseccops-fe-v2, repo-analyzer)"
  echo "  - 2 ECR Repositories (repo-analyzer-test, buildkit-cache)"
  echo ""
  read -p "Are you sure you want to proceed? (type 'yes' to confirm): " CONFIRM

  if [[ "$CONFIRM" != "yes" ]]; then
    echo "Deletion cancelled."
    exit 0
  fi

  echo ""
  echo "Deleting CloudFormation stack: $STACK_NAME ..."
  aws cloudformation delete-stack --region "$REGION" --stack-name "$STACK_NAME"

  echo "Waiting for stack deletion to complete ..."
  aws cloudformation wait stack-delete-complete --region "$REGION" --stack-name "$STACK_NAME"

  echo ""
  echo "Successfully deleted stack: $STACK_NAME"
  echo "All IAM roles and ECR repositories have been removed."
  exit 0
fi

if [[ -z "$CLUSTER_NAME" ]]; then
  echo "Error: --cluster is required (unless using --delete)"
  echo "Usage:"
  echo "  Deploy:       bash setup-iam.sh --cluster <eks-cluster-name> [--prefix prod] [--namespace devseccops] [--region ap-south-1] [--kms-key <key-id>]"
  echo "  Deploy (dry): bash setup-iam.sh --cluster <eks-cluster-name> --dry-run"
  echo "  Delete (dry): bash setup-iam.sh --delete --dry-run [--stack devseccops-iam] [--region ap-south-1]"
  echo "  Delete:       bash setup-iam.sh --delete [--stack devseccops-iam] [--region ap-south-1]"
  echo ""
  echo "Options:"
  echo "  --kms-key     KMS Key ID for SSM decryption (auto-detected from alias if not provided)"
  exit 1
fi

# ── write embedded CF template to a temp file ──────────────────────────────────
TMPFILE=$(mktemp /tmp/devseccops-iam-XXXXXX.yaml)
trap 'rm -f "$TMPFILE"' EXIT

cat > "$TMPFILE" << 'CFTEMPLATE'
AWSTemplateFormatVersion: "2010-09-09"
Description: >
  DevSecOps Platform - IRSA IAM roles for all four services
  (devseccops-be, devseccops-be-go, devseccops-fe-v2, repo-analyzer).
  Run once per EKS cluster. Re-running is safe (CloudFormation is idempotent).

Parameters:
  ClusterName:
    Type: String
    Description: Name of the EKS cluster
  Prefix:
    Type: String
    Default: prod
    Description: Resource name prefix (e.g. dev, prod, client-name)
  Namespace:
    Type: String
    Default: devseccops
    Description: Kubernetes namespace the stack is deployed into
  Region:
    Type: String
    Default: ap-south-1
    Description: AWS region where the EKS cluster runs
  OidcProvider:
    Type: String
    Description: OIDC provider ID (part after https://)
  KmsKeyId:
    Type: String
    Description: KMS Key ID for decrypting SSM parameters

Conditions: {}

Resources:

  # ── ECR Repositories ──────────────────────────────────────────────────────

  RepoAnalyzerTestRepository:
    Type: AWS::ECR::Repository
    DeletionPolicy: Delete
    Properties:
      RepositoryName: repo-analyzer-test
      ImageScanningConfiguration:
        ScanOnPush: false
      EmptyOnDelete: true
      LifecyclePolicy:
        LifecyclePolicyText: |
          {
            "rules": [
              {
                "rulePriority": 1,
                "description": "Delete untagged images older than 7 days",
                "selection": {
                  "tagStatus": "untagged",
                  "countType": "sinceImagePushed",
                  "countUnit": "days",
                  "countNumber": 7
                },
                "action": {
                  "type": "expire"
                }
              },
              {
                "rulePriority": 2,
                "description": "Keep only last 10 images (all)",
                "selection": {
                  "tagStatus": "any",
                  "countType": "imageCountMoreThan",
                  "countNumber": 10
                },
                "action": {
                  "type": "expire"
                }
              }
            ]
          }
      Tags:
        - Key: Name
          Value: !Sub "${Prefix}-repo-analyzer-test"
        - Key: Environment
          Value: !Ref Prefix
        - Key: Purpose
          Value: "Temporary test images - auto-deleted after 7 days"

  BuildkitCacheRepository:
    Type: AWS::ECR::Repository
    DeletionPolicy: Delete
    Properties:
      RepositoryName: buildkit-cache
      ImageScanningConfiguration:
        ScanOnPush: false
      EmptyOnDelete: true
      LifecyclePolicy:
        LifecyclePolicyText: |
          {
            "rules": [
              {
                "rulePriority": 1,
                "description": "Delete untagged cache images older than 14 days",
                "selection": {
                  "tagStatus": "untagged",
                  "countType": "sinceImagePushed",
                  "countUnit": "days",
                  "countNumber": 14
                },
                "action": {
                  "type": "expire"
                }
              },
              {
                "rulePriority": 2,
                "description": "Keep only last 20 cache layers (all)",
                "selection": {
                  "tagStatus": "any",
                  "countType": "imageCountMoreThan",
                  "countNumber": 20
                },
                "action": {
                  "type": "expire"
                }
              }
            ]
          }
      Tags:
        - Key: Name
          Value: !Sub "${Prefix}-buildkit-cache"
        - Key: Environment
          Value: !Ref Prefix
        - Key: Purpose
          Value: "Build cache - auto-deleted after 14 days"

  # ── IAM Roles ─────────────────────────────────────────────────────────────

  DevseccopsBeRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: !Sub "${Prefix}-devseccops-be-sa-role"
      AssumeRolePolicyDocument: !Sub |
        {
          "Version": "2012-10-17",
          "Statement": [{
            "Effect": "Allow",
            "Principal": { "Federated": "arn:aws:iam::${AWS::AccountId}:oidc-provider/${OidcProvider}" },
            "Action": "sts:AssumeRoleWithWebIdentity",
            "Condition": { "StringEquals": { "${OidcProvider}:sub": "system:serviceaccount:${Namespace}:${Prefix}-devseccops-be-sa" } }
          }]
        }
      Policies:
        - PolicyName: !Sub "${Prefix}-devseccops-be-policy"
          PolicyDocument:
            Version: "2012-10-17"
            Statement:
              - Effect: Allow
                Action: [logs:PutLogEvents, logs:GetLogEvents, logs:DescribeLogStreams, logs:CreateLogStream, logs:CreateLogGroup]
                Resource:
                  - !Sub "arn:aws:logs:${Region}:${AWS::AccountId}:log-group:${Prefix}-devseccops-be:log-stream:*"
                  - !Sub "arn:aws:logs:${Region}:${AWS::AccountId}:log-group:${Prefix}-devseccops-be:log-stream:"
              - Effect: Allow
                Action: ssm:*
                Resource: "*"
              - Effect: Allow
                Action: [kms:Decrypt, kms:DescribeKey]
                Resource: !Sub "arn:aws:kms:${Region}:${AWS::AccountId}:key/${KmsKeyId}"

  DevseccopsBeGoRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: !Sub "${Prefix}-devseccops-be-go-sa-role"
      AssumeRolePolicyDocument: !Sub |
        {
          "Version": "2012-10-17",
          "Statement": [{
            "Effect": "Allow",
            "Principal": { "Federated": "arn:aws:iam::${AWS::AccountId}:oidc-provider/${OidcProvider}" },
            "Action": "sts:AssumeRoleWithWebIdentity",
            "Condition": { "StringEquals": { "${OidcProvider}:sub": "system:serviceaccount:${Namespace}:${Prefix}-devseccops-be-go-sa" } }
          }]
        }
      Policies:
        - PolicyName: !Sub "${Prefix}-devseccops-be-go-policy"
          PolicyDocument:
            Version: "2012-10-17"
            Statement:
              - Effect: Allow
                Action: [logs:PutLogEvents, logs:GetLogEvents, logs:DescribeLogStreams, logs:CreateLogStream, logs:CreateLogGroup]
                Resource:
                  - !Sub "arn:aws:logs:${Region}:${AWS::AccountId}:log-group:${Prefix}-devseccops-be-go:log-stream:*"
                  - !Sub "arn:aws:logs:${Region}:${AWS::AccountId}:log-group:${Prefix}-devseccops-be-go:log-stream:"
              - Effect: Allow
                Action: ssm:*
                Resource: !Sub "arn:aws:ssm:${Region}:${AWS::AccountId}:parameter/*"
              - Effect: Allow
                Action: eks:DescribeCluster
                Resource: !Sub "arn:aws:eks:${Region}:${AWS::AccountId}:cluster/${ClusterName}"
              - Effect: Allow
                Action: [kms:Decrypt, kms:DescribeKey]
                Resource: !Sub "arn:aws:kms:${Region}:${AWS::AccountId}:key/${KmsKeyId}"

  DevseccopsFev2Role:
    Type: AWS::IAM::Role
    Properties:
      RoleName: !Sub "${Prefix}-devseccops-fe-v2-sa-role"
      AssumeRolePolicyDocument: !Sub |
        {
          "Version": "2012-10-17",
          "Statement": [{
            "Effect": "Allow",
            "Principal": { "Federated": "arn:aws:iam::${AWS::AccountId}:oidc-provider/${OidcProvider}" },
            "Action": "sts:AssumeRoleWithWebIdentity",
            "Condition": { "StringEquals": { "${OidcProvider}:sub": "system:serviceaccount:${Namespace}:${Prefix}-devseccops-fe-v2-sa" } }
          }]
        }
      Policies:
        - PolicyName: !Sub "${Prefix}-devseccops-fe-v2-policy"
          PolicyDocument:
            Version: "2012-10-17"
            Statement:
              - Effect: Allow
                Action: [logs:PutLogEvents, logs:GetLogEvents, logs:DescribeLogStreams, logs:CreateLogStream, logs:CreateLogGroup]
                Resource:
                  - !Sub "arn:aws:logs:${Region}:${AWS::AccountId}:log-group:${Prefix}-devseccops-fe-v2:log-stream:*"
                  - !Sub "arn:aws:logs:${Region}:${AWS::AccountId}:log-group:${Prefix}-devseccops-fe-v2:log-stream:"
              - Effect: Allow
                Action: ssm:*
                Resource:
                  - !Sub "arn:aws:ssm:${Region}:${AWS::AccountId}:parameter/${Prefix}/devseccops/*"
                  - !Sub "arn:aws:ssm:${Region}:${AWS::AccountId}:parameter/${Prefix}/devseccops-fe-v2/*"
              - Effect: Allow
                Action: [ec2:DescribeInstances, ec2:DescribeVolumes, ec2:DescribeAddresses, ec2:DescribeTags]
                Resource: "*"
              - Effect: Allow
                Action: [kms:Decrypt, kms:DescribeKey]
                Resource: !Sub "arn:aws:kms:${Region}:${AWS::AccountId}:key/${KmsKeyId}"

  RepoAnalyzerRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: !Sub "${Prefix}-repo-analyzer-sa-role"
      AssumeRolePolicyDocument: !Sub |
        {
          "Version": "2012-10-17",
          "Statement": [{
            "Effect": "Allow",
            "Principal": { "Federated": "arn:aws:iam::${AWS::AccountId}:oidc-provider/${OidcProvider}" },
            "Action": "sts:AssumeRoleWithWebIdentity",
            "Condition": { "StringEquals": { "${OidcProvider}:sub": "system:serviceaccount:${Namespace}:${Prefix}-repo-analyzer-sa" } }
          }]
        }
      Policies:
        - PolicyName: !Sub "${Prefix}-repo-analyzer-policy"
          PolicyDocument:
            Version: "2012-10-17"
            Statement:
              - Effect: Allow
                Action: [logs:PutLogEvents, logs:GetLogEvents, logs:DescribeLogStreams, logs:CreateLogStream, logs:CreateLogGroup]
                Resource:
                  - !Sub "arn:aws:logs:${Region}:${AWS::AccountId}:log-group:${Prefix}-repo-analyzer:log-stream:*"
                  - !Sub "arn:aws:logs:${Region}:${AWS::AccountId}:log-group:${Prefix}-repo-analyzer:log-stream:"
                  - !Sub "arn:aws:logs:${Region}:${AWS::AccountId}:log-group:repo-analyzer:log-stream:*"
                  - !Sub "arn:aws:logs:${Region}:${AWS::AccountId}:log-group:repo-analyzer:log-stream:"
              - Effect: Allow
                Action: ssm:*
                Resource:
                  - !Sub "arn:aws:ssm:${Region}:${AWS::AccountId}:parameter/${Prefix}/repo-analyzer"
                  - !Sub "arn:aws:ssm:${Region}:${AWS::AccountId}:parameter/${Prefix}/repo-analyzer/*"
              - Effect: Allow
                Action: ecr:GetAuthorizationToken
                Resource: "*"
              - Effect: Allow
                Action: [ecr:BatchCheckLayerAvailability, ecr:GetDownloadUrlForLayer, ecr:BatchGetImage, ecr:InitiateLayerUpload, ecr:UploadLayerPart, ecr:CompleteLayerUpload, ecr:PutImage]
                Resource:
                  - !Sub "arn:aws:ecr:${Region}:${AWS::AccountId}:repository/buildkit-cache"
                  - !Sub "arn:aws:ecr:${Region}:${AWS::AccountId}:repository/repo-analyzer-test"
              - Effect: Allow
                Action: [kms:Decrypt, kms:DescribeKey]
                Resource: !Sub "arn:aws:kms:${Region}:${AWS::AccountId}:key/${KmsKeyId}"

Outputs:
  BeRoleArn:
    Description: IAM Role ARN for devseccops-be
    Value: !GetAtt DevseccopsBeRole.Arn
  BeGoRoleArn:
    Description: IAM Role ARN for devseccops-be-go
    Value: !GetAtt DevseccopsBeGoRole.Arn
  FeV2RoleArn:
    Description: IAM Role ARN for devseccops-fe-v2
    Value: !GetAtt DevseccopsFev2Role.Arn
  RepoAnalyzerRoleArn:
    Description: IAM Role ARN for repo-analyzer
    Value: !GetAtt RepoAnalyzerRole.Arn
  RepoAnalyzerTestRepositoryUri:
    Description: ECR Repository URI for repo-analyzer-test (auto-cleanup after 7 days)
    Value: !Sub "${AWS::AccountId}.dkr.ecr.${Region}.amazonaws.com/repo-analyzer-test"
  BuildkitCacheRepositoryUri:
    Description: ECR Repository URI for buildkit-cache (auto-cleanup after 14 days)
    Value: !Sub "${AWS::AccountId}.dkr.ecr.${Region}.amazonaws.com/buildkit-cache"
CFTEMPLATE

# ── derive OIDC provider ───────────────────────────────────────────────────────
echo "Fetching OIDC provider for cluster: $CLUSTER_NAME ..."
OIDC_URL=$(aws eks describe-cluster --name "$CLUSTER_NAME" --region "$REGION" --query "cluster.identity.oidc.issuer" --output text)
OIDC_PROVIDER="${OIDC_URL#https://}"

if [[ -z "$OIDC_PROVIDER" ]]; then
  echo "Error: Could not retrieve OIDC provider. Make sure OIDC is enabled on the cluster."
  exit 1
fi

echo "OIDC provider: $OIDC_PROVIDER"

# ── fetch or prompt for KMS key ID ────────────────────────────────────────────
if [[ -z "$KMS_KEY_ID" ]]; then
  echo "Fetching KMS keys with alias matching environment prefix..."

  # Try to find a KMS key with alias matching the prefix
  ALIAS_NAME="alias/${PREFIX}-devseccops"
  KMS_KEY_ID=$(aws kms list-aliases --region "$REGION" --query "Aliases[?AliasName=='$ALIAS_NAME'].TargetKeyId" --output text 2>/dev/null || echo "")

  if [[ -n "$KMS_KEY_ID" ]]; then
    echo "Found KMS key for alias '$ALIAS_NAME': $KMS_KEY_ID"
  else
    echo "Warning: Could not auto-detect KMS key for alias '$ALIAS_NAME'"
    echo ""
    echo "Available KMS keys in your account:"
    aws kms list-keys --region "$REGION" --query "Keys[*].KeyId" --output table 2>/dev/null || echo "Could not list keys"
    echo ""
    echo "You can manually specify a KMS key ID or skip KMS permissions."
    read -p "Enter KMS Key ID (or press Enter to skip KMS permissions): " KMS_KEY_INPUT
    KMS_KEY_ID="${KMS_KEY_INPUT:-skip}"
  fi
fi

if [[ "$KMS_KEY_ID" != "skip" ]]; then
  echo "Using KMS Key ID: $KMS_KEY_ID"
fi

# ── deploy or dry-run ─────────────────────────────────────────────────────────
if [[ "$DRY_RUN" == "true" ]]; then
  echo ""
  echo "Dry-run mode — creating changeset preview (nothing will be applied) ..."
  CHANGESET_NAME="devseccops-iam-dryrun-$(date +%s)"

  # determine type for dry-run changeset
  STACK_STATUS=$(aws cloudformation describe-stacks --region "$REGION" --stack-name "$STACK_NAME" --query "Stacks[0].StackStatus" --output text 2>/dev/null || echo "DOES_NOT_EXIST")
  CHANGESET_TYPE="UPDATE"
  [[ "$STACK_STATUS" == "DOES_NOT_EXIST" ]] && CHANGESET_TYPE="CREATE"

  CF_PARAMS="ParameterKey=ClusterName,ParameterValue=$CLUSTER_NAME ParameterKey=Prefix,ParameterValue=$PREFIX ParameterKey=Namespace,ParameterValue=$NAMESPACE ParameterKey=Region,ParameterValue=$REGION ParameterKey=OidcProvider,ParameterValue=$OIDC_PROVIDER"
  [[ "$KMS_KEY_ID" != "skip" ]] && CF_PARAMS="$CF_PARAMS ParameterKey=KmsKeyId,ParameterValue=$KMS_KEY_ID"

  aws cloudformation create-change-set --region "$REGION" --stack-name "$STACK_NAME" --template-body "file://$TMPFILE" --change-set-name "$CHANGESET_NAME" --change-set-type "$CHANGESET_TYPE" --capabilities CAPABILITY_NAMED_IAM --parameters $CF_PARAMS

  echo "Waiting for changeset to be ready ..."
  aws cloudformation wait change-set-create-complete --region "$REGION" --stack-name "$STACK_NAME" --change-set-name "$CHANGESET_NAME"

  echo ""
  echo "Changes that would be applied:"
  aws cloudformation describe-change-set --region "$REGION" --stack-name "$STACK_NAME" --change-set-name "$CHANGESET_NAME" --query "Changes[*].ResourceChange.{Action:Action,Resource:LogicalResourceId,Type:ResourceType}" --output table
  aws cloudformation delete-change-set --region "$REGION" --stack-name "$STACK_NAME" --change-set-name "$CHANGESET_NAME"
  echo ""
  echo "Re-run without --dry-run to apply."
  exit 0
fi

echo ""
echo "Deploying IAM roles (stack: $STACK_NAME) ..."

CF_OVERRIDES="ClusterName=$CLUSTER_NAME Prefix=$PREFIX Namespace=$NAMESPACE Region=$REGION OidcProvider=$OIDC_PROVIDER"
[[ "$KMS_KEY_ID" != "skip" ]] && CF_OVERRIDES="$CF_OVERRIDES KmsKeyId=$KMS_KEY_ID"

aws cloudformation deploy --region "$REGION" --stack-name "$STACK_NAME" --template-file "$TMPFILE" --capabilities CAPABILITY_NAMED_IAM --parameter-overrides $CF_OVERRIDES

# ── print outputs ──────────────────────────────────────────────────────────────
echo ""
echo "✓ Deployment complete!"
echo ""
echo "Created resources:"
echo "  - 4 IAM Roles (with IRSA trust policies)"
echo "  - 2 ECR Repositories (with automatic cleanup policies)"
echo ""
echo "Resource details:"
aws cloudformation describe-stacks \
  --region "$REGION" \
  --stack-name "$STACK_NAME" \
  --query "Stacks[0].Outputs[*].[OutputKey,OutputValue]" \
  --output table
