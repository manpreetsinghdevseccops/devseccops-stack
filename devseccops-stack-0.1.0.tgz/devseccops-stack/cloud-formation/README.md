# DevSecOps Platform - IAM Setup

This directory contains AWS CloudFormation templates and scripts to set up IAM roles for the DevSecOps platform using **IRSA (IAM Roles for Service Accounts)** in Amazon EKS.

## What It Does

Creates **4 IAM roles** (one for each microservice) and **2 ECR repositories** with automatic cleanup policies:

### IAM Roles

| Service | IAM Role | AWS Permissions |
|---------|----------|-----------------|
| **devseccops-be** | `{prefix}-devseccops-be-sa-role` | CloudWatch Logs, SSM Parameter Store (full) |
| **devseccops-be-go** | `{prefix}-devseccops-be-go-sa-role` | CloudWatch Logs, SSM Parameter Store, EKS DescribeCluster |
| **devseccops-fe-v2** | `{prefix}-devseccops-fe-v2-sa-role` | CloudWatch Logs, SSM (scoped), EC2 read-only |
| **repo-analyzer** | `{prefix}-repo-analyzer-sa-role` | CloudWatch Logs, SSM, ECR (auth + push/pull) |

### ECR Repositories (with Auto-Cleanup)

| Repository | Purpose | Cleanup Policy |
|------------|---------|----------------|
| **repo-analyzer-test** | Temporary test images | Deletes images older than 7 days, keeps max 10 images |
| **buildkit-cache** | Build cache layers | Deletes images older than 14 days, keeps max 20 layers |

> **Note:** Both ECR repositories automatically clean up old images to prevent storage costs from accumulating.

## Prerequisites

- AWS CLI installed and configured
- IAM permissions: `iam:CreateRole`, `iam:AttachRolePolicy`, CloudFormation permissions
- EKS cluster with OIDC provider enabled
- `kubectl` access to the cluster (optional, for verification)

## Quick Reference

| Action | Command |
|--------|---------|
| **Preview deployment** | `bash cloud-formation/setup-iam.sh --cluster <name> --dry-run` |
| **Deploy/Update** | `bash cloud-formation/setup-iam.sh --cluster <name>` |
| **Preview deletion** | `bash cloud-formation/setup-iam.sh --delete --dry-run` |
| **Delete** | `bash cloud-formation/setup-iam.sh --delete` |

## Usage

### 1. Dry-Run (Preview Changes)

Preview what resources will be created without applying any changes:

```bash
bash cloud-formation/setup-iam.sh \
  --cluster <your-eks-cluster-name> \
  --prefix prod \
  --namespace devseccops \
  --region ap-south-1 \
  --dry-run
```

**Example:**
```bash
bash cloud-formation/setup-iam.sh \
  --cluster prod-devseccops-eks \
  --dry-run
```

### 2. Deploy IAM Roles

Create/update the IAM roles:

```bash
bash cloud-formation/setup-iam.sh \
  --cluster <your-eks-cluster-name> \
  --prefix prod \
  --namespace devseccops \
  --region ap-south-1
```

**Example:**
```bash
bash cloud-formation/setup-iam.sh \
  --cluster prod-devseccops-eks \
  --prefix prod \
  --namespace devseccops
  --region ap-south-1
```

### 3. Preview Resources to Delete (Dry-Run)

See what resources will be deleted without actually deleting them:

```bash
bash cloud-formation/setup-iam.sh --delete --dry-run
```

**With custom stack name:**
```bash
bash cloud-formation/setup-iam.sh \
  --delete \
  --dry-run \
  --stack devseccops-iam \
  --region ap-south-1
```

This will show:
- Stack status
- All IAM roles that will be deleted
- Stack outputs (Role ARNs)

### 4. Delete All Resources

Remove the CloudFormation stack and all IAM roles:

```bash
bash cloud-formation/setup-iam.sh --delete
```

**With custom stack name:**
```bash
bash cloud-formation/setup-iam.sh \
  --delete \
  --stack devseccops-iam \
  --region ap-south-1
```

> **Note:** You'll be prompted to type `yes` to confirm deletion.

## Parameters

| Parameter | Required | Default | Description |
|-----------|----------|---------|-------------|
| `--cluster` | Yes* | - | EKS cluster name (*not required for `--delete`) |
| `--prefix` | No | `prod` | Environment prefix (dev, staging, prod) |
| `--namespace` | No | `devseccops` | Kubernetes namespace |
| `--region` | No | `ap-south-1` | AWS region |
| `--stack` | No | `devseccops-iam` | CloudFormation stack name |
| `--dry-run` | No | `false` | Preview changes without applying |
| `--delete` | No | `false` | Delete the CloudFormation stack |

## Output

After deployment, you'll see the IAM Role ARNs and ECR Repository URIs:

```
BeRoleArn                    | arn:aws:iam::123456789012:role/prod-devseccops-be-sa-role
BeGoRoleArn                  | arn:aws:iam::123456789012:role/prod-devseccops-be-go-sa-role
FeV2RoleArn                  | arn:aws:iam::123456789012:role/prod-devseccops-fe-v2-sa-role
RepoAnalyzerRoleArn          | arn:aws:iam::123456789012:role/prod-repo-analyzer-sa-role
RepoAnalyzerTestRepositoryUri| 123456789012.dkr.ecr.ap-south-1.amazonaws.com/repo-analyzer-test
BuildkitCacheRepositoryUri   | 123456789012.dkr.ecr.ap-south-1.amazonaws.com/buildkit-cache
```

## Integration with Helm Charts

These role ARNs are automatically referenced in your Helm chart values. Each service's ServiceAccount should have this annotation:

```yaml
serviceAccount:
  create: true
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/prod-devseccops-be-sa-role
  name: prod-devseccops-be-sa
```

The Helm charts in this repository already include these configurations in their `values.yaml` files.

## How IRSA Works

1. **OIDC Provider**: EKS cluster has an OIDC identity provider
2. **IAM Trust Policy**: Each IAM role trusts the OIDC provider for specific ServiceAccounts
3. **Pod Authentication**: Pods using the annotated ServiceAccount can assume the IAM role
4. **AWS SDK**: Application code uses AWS SDK, which automatically picks up credentials from the pod's service account token

No AWS access keys or secret keys are needed in your application configuration!

## Verification

### Check CloudFormation Stack
```bash
aws cloudformation describe-stacks \
  --region ap-south-1 \
  --stack-name devseccops-iam \
  --query "Stacks[0].{Status:StackStatus,Outputs:Outputs}"
```

### Verify IAM Roles
```bash
aws iam get-role --role-name prod-devseccops-be-sa-role
```

### Test from a Pod
```bash
kubectl run -it --rm debug \
  --image=amazon/aws-cli \
  --serviceaccount=prod-devseccops-be-sa \
  --namespace=devseccops \
  -- sts get-caller-identity
```

## Re-running is Safe

CloudFormation is **idempotent** - re-running the deployment script will:
- Update existing roles if the template changed
- Leave unchanged resources as-is
- Not create duplicates

## Troubleshooting

### OIDC Provider Not Found
```
Error: Could not retrieve OIDC provider
```
**Solution:** Enable OIDC provider on your EKS cluster:
```bash
eksctl utils associate-iam-oidc-provider \
  --cluster <cluster-name> \
  --region ap-south-1 \
  --approve
```

### Access Denied Errors
Ensure your AWS credentials have these permissions:
- `iam:CreateRole`
- `iam:PutRolePolicy`
- `iam:AttachRolePolicy`
- `cloudformation:CreateStack`
- `cloudformation:UpdateStack`
- `cloudformation:DescribeStacks`

### Stack Already Exists
If the stack exists but you want to start fresh:
```bash
bash cloud-formation/setup-iam.sh --delete
# Then re-run the deployment
```

## Files

- **`setup-iam.sh`**: Main deployment script with embedded CloudFormation template
- **`iam-setup.yaml`**: Standalone CloudFormation template (reference copy)
- **`README.md`**: This file

## ECR Repository Lifecycle Policies

Both ECR repositories have automated cleanup policies to prevent indefinite storage:

### repo-analyzer-test
- **Rule 1**: Deletes any image older than 7 days
- **Rule 2**: Keeps only the last 10 images
- **Purpose**: Temporary test images should not persist

### buildkit-cache
- **Rule 1**: Deletes cache layers older than 14 days
- **Rule 2**: Keeps only the last 20 cache layers
- **Purpose**: Build caches are regenerated and don't need long retention

These policies run automatically in the background and help control AWS storage costs.

## Security Notes

- IAM roles use least-privilege principles
- SSM Parameter Store access is scoped where possible
- ECR access is limited to specific repositories
- CloudWatch Logs access is scoped to service-specific log groups
- ECR repositories have lifecycle policies to prevent indefinite storage
- Consider further restricting `ssm:*` to specific actions in production

## Support

For issues or questions:
1. Check AWS CloudFormation console for stack events
2. Review IAM role trust policies
3. Verify EKS OIDC provider is configured correctly
4. Check Kubernetes ServiceAccount annotations match role ARNs


aws s3 cp cloud-formation/setup-ssm.sh s3://devseccops-assets/setup-ssm.sh --acl public-read --profile default

aws s3 cp cloud-formation/setup-ssm.sh s3://devseccops-assets/setup-iam.sh --acl public-read --profile default