<!----------------------------------------------------------   HOW TO INSTALL - DEVSECCOPS-TOOL  --------------------------------------------------------->



<!-- IAM ROLES -->

<!-- CREATE -->

 bash <(curl -fsSL https://devseccops-assets.s3.ap-south-1.amazonaws.com/setup-iam.sh) \
    --namespace devseccops \
    --prefix prod \
    --cluster prod-devseccops-eks-cluster \
    --kms-key 889d85fd-edbd-4af8-87d6-138d978a8bc7 \
    --region ap-south-1


<!-- DELETE -->

 bash <(curl -fsSL https://devseccops-assets.s3.ap-south-1.amazonaws.com/setup-iam.sh) \
    --delete \
    --region ap-south-1 \
    --dry-run


<!-- SSM PARAMETERS -->

<!-- UPLOAD -->
bash <(curl -fsSL https://devseccops-assets.s3.ap-south-1.amazonaws.com/setup-ssm.sh) upload \
    --environment prod \
    --aws-access-key AKIAR43VGNJV7I56UWR3 \
    --aws-secret-key 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 \
    --gmail-user ajeetsingh@devseccops.ai \
    --gmail-pass adtqswlczzixidlm \
    --domain devseccops.ai \
    --frontend https://demo.devseccops.ai \
    --backend https://demo-api.devseccops.ai \
    --engine-repo-owner devseccops \
    --engine-repo-name devseccops-engine \
    --github-token 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 \
    --docker-hub-password dckr_pat_Get8OtdhhgUJ773pkO-qXkl2zy0 \
    --docker-hub-username manpreet740 \
    --keyid 889d85fd-edbd-4af8-87d6-138d978a8bc7 \
    --region ap-south-1 \
    --dry-run


<!-- DELETE -->
bash <(curl -fsSL https://devseccops-assets.s3.ap-south-1.amazonaws.com/setup-ssm.sh) delete \
    --environment prod \
    --region ap-south-1 \
    --dry-run



helm repo add devseccops https://manpreetsinghdevseccops.github.io/devseccops-stack/

helm repo update

helm upgrade --install devseccops devseccops/devseccops-stack \
    -n devseccops \
    --set global.domain.frontend="demo.devseccops.ai" \
    --set global.domain.backend="demo-api.devseccops.ai" \
    --set global.certificateArn="arn:aws:acm:ap-south-1:130705418859:certificate/29231324-d2ff-4880-b554-6c0478a839f2" \
    --set global.albGroupName="shared-prod-alb" \
    --create-namespace




helm upgrade --install devseccops devseccops/devseccops-stack -n devseccops 
